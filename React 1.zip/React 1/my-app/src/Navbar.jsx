import React from "react";
import { Link } from "react-router-dom";

function Navbar() {
  return (
    <nav className="navbar">

      <Link to="/">Home</Link>

      <Link to="/about">About</Link>

      <Link to="/education">Education</Link>

      <Link to="/skills">Skills</Link>

      <Link to="/contact">Contact</Link>

    </nav>
  );
}

export default Navbar;