import React from "react";

function Header() {
  return (
    <header>
      <h1>Student Portal</h1>
      <p>Student Information Management</p>
    </header>
  );
}

export default Header;