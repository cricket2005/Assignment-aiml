import React from "react";

function StudentCard(props) {

  return (
    <div className="student-card">

      <img
        src={props.photo}
        alt={props.name}
      />

      <h3>{props.name}</h3>

      <p>
        <b>Roll Number:</b> {props.roll}
      </p>

      <p>
        <b>Department:</b> {props.department}
      </p>

      <p>
        <b>Semester:</b> {props.semester}
      </p>

      <p>
        <b>CGPA:</b> {props.cgpa}
      </p>

    </div>
  );
}

export default StudentCard;