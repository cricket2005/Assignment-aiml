import React from "react";
import { Link } from "react-router-dom";

function Home() {
  return (
    <section className="section home">

      <h2>Welcome to My Portfolio</h2>

      <p>
        Hello! I am a student and web developer.
      </p>

      <p>
        I love creating websites and learning new technologies.
      </p>

      <Link to="/about">
        <button>Know More About Me</button>
      </Link>

    </section>
  );
}

export default Home;