import React from "react";

function Education() {
  return (
    <section className="section">

      <h2>Education</h2>

      <div className="education-container">

        <div className="card">

          <h3>Master's Degree</h3>

          <p>Computer Application</p>

          <p>University Name</p>

          <p>2024 - 2026</p>

        </div>

        <div className="card">

          <h3>Bachelor's Degree</h3>

          <p>Computer Application</p>

          <p>College Name</p>

          <p>2021 - 2024</p>

        </div>

        <div className="card">

          <h3>Higher Secondary</h3>

          <p>Science</p>

          <p>School Name</p>

          <p>2021</p>

        </div>

      </div>

    </section>
  );
}

export default Education;