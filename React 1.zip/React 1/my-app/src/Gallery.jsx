import React from "react";

function Gallery() {
  return (
    <div>
      <h1>Gallery Page</h1>

      <img
        src="images/pic1.jpg"
        alt="Gallery 1"
      />

      <img
        src="images/pic2.jpg"
        alt="Gallery 2"
      />

      <img
        src="images/pic3.jpg"
        alt="Gallery 3"
      />
    </div>
  );
}

export default Gallery;