import React, { useState } from "react";
import Header from "./Header";
import StudentList from "./StudentList";
import Footer from "./Footer";
import "./App.css";

function App() {

  const [students, setStudents] = useState([
    {
      name: "Rahul Das",
      roll: "101",
      department: "Computer Science",
      semester: "5th",
      cgpa: 8.7,
      photo: "https://randomuser.me/api/portraits/men/1.jpg"
    },
    {
      name: "Priya Sen",
      roll: "102",
      department: "Information Technology",
      semester: "4th",
      cgpa: 9.2,
      photo: "https://randomuser.me/api/portraits/women/2.jpg"
    },
    {
      name: "Amit Roy",
      roll: "103",
      department: "Computer Science",
      semester: "6th",
      cgpa: 7.8,
      photo: "https://randomuser.me/api/portraits/men/3.jpg"
    },
    {
      name: "Sneha Das",
      roll: "104",
      department: "Electronics",
      semester: "3rd",
      cgpa: 8.9,
      photo: "https://randomuser.me/api/portraits/women/4.jpg"
    }
  ]);

  // Sort students by CGPA
  const sortByCGPA = () => {
    const sorted = [...students].sort((a, b) => b.cgpa - a.cgpa);
    setStudents(sorted);
  };

  return (
    <div>
      <Header />

      <div className="container">
        <h2 className="text-center">Student Information Portal</h2>

        <div className="text-center">
          <button onClick={sortByCGPA} className="sort-btn">
            Sort by CGPA
          </button>
        </div>

        <StudentList students={students} />
      </div>

      <Footer />
    </div>
  );
}

export default App;