import React from "react";

function Contact() {
  return (
    <section className="section">

      <h2>Contact Me</h2>

      <div className="contact-box">

        <p>
          <strong>Email:</strong> student@example.com
        </p>

        <p>
          <strong>Phone:</strong> +91 9876543210
        </p>

        <p>
          <strong>Address:</strong> Kolkata, India
        </p>

        <form>

          <input
            type="text"
            placeholder="Enter your name"
          />

          <input
            type="email"
            placeholder="Enter your email"
          />

          <textarea
            placeholder="Enter your message"
          ></textarea>

          <button type="submit">
            Send Message
          </button>

        </form>

      </div>

    </section>
  );
}

export default Contact;