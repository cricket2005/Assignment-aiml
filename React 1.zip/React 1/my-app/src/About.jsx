import React from "react";

function About() {
  return (
    <section className="section">

      <h2>About Me</h2>

      <div className="about-box">

        <h3>Hello, I am S Mandal</h3>

        <p>
          I am a passionate student interested in web development
          and programming.
        </p>

        <p>
          I enjoy creating websites and learning new technologies.
        </p>

        <p>
          My goal is to become a professional full-stack developer.
        </p>

      </div>

    </section>
  );
}

export default About;