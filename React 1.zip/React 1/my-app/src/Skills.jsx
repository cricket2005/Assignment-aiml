import React from "react";

function Skills() {
  return (
    <section className="section">

      <h2>My Skills</h2>

      <div className="skills-container">

        <div className="skill">HTML</div>

        <div className="skill">CSS</div>

        <div className="skill">JavaScript</div>

        <div className="skill">React JS</div>

        <div className="skill">Node JS</div>

        <div className="skill">PHP</div>

        <div className="skill">MySQL</div>

        <div className="skill">MongoDB</div>

      </div>

    </section>
  );
}

export default Skills;